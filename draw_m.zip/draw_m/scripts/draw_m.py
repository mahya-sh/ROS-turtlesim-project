#!/usr/bin/env python3

import rospy
from turtlesim.srv import Spawn, Kill
from geometry_msgs.msg import Twist


def spawn_turtle(name, x, y):
    rospy.wait_for_service('spawn')
    try:
        spawn = rospy.ServiceProxy('spawn', Spawn)
        spawn(x, y, 0, name)
    except rospy.ServiceException as e:
        print("Service call failed:", e)


def delete_turtle(name):
    rospy.wait_for_service('kill')
    try:
        kill = rospy.ServiceProxy('kill', Kill)
        kill(name)
    except rospy.ServiceException as e:
        print("Service call failed:", e)


def set_turtle_positions():
    rospy.init_node('set_turtle_positions', anonymous=True)

    # Delete existing turtles
    ##for i in range(1, 20):
    ##    delete_turtle('turtle{}'.format(i))
    delete_turtle('turtle1')

    # Spawn 4 turtles for first line
    for i in range(1, 5): 
        spawn_turtle('turtle{}'.format(i),3.5,  i)
    # Spawn 4 turtles for second line    
    for i in range(5, 9):
        spawn_turtle('turtle{}'.format(i),7.5,  i-4)
        
    spawn_turtle('turtle{}'.format(17),4.5,  3)
    spawn_turtle('turtle{}'.format(18),5.5,  2)
    spawn_turtle('turtle{}'.format(19),6.5,  3)    
        
        
        
    
    spawn_turtle('turtle{}'.format(9),5,  10)
    spawn_turtle('turtle{}'.format(10),6,  10)
    spawn_turtle('turtle{}'.format(11),6.9,  9.2)
    spawn_turtle('turtle{}'.format(12),4.1,  9.2)
    spawn_turtle('turtle{}'.format(13),6.4,  8.4)
    spawn_turtle('turtle{}'.format(14),4.6,  8.4)
    spawn_turtle('turtle{}'.format(15),7.4,  8.4)
    spawn_turtle('turtle{}'.format(16),3.6,  8.4)
    
    
    
    
    # Stop the turtles from moving
    stop_publisher = rospy.Publisher('/turtle*/cmd_vel', Twist, queue_size=10)
    stop_msg = Twist()
    stop_publisher.publish(stop_msg)


if __name__ == '__main__':
    try:
        set_turtle_positions()
        rospy.spin()  # Keep the program running until manually stopped
    except rospy.ROSInterruptException:
        pass

