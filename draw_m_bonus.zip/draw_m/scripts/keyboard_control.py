#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from pynput import keyboard

class TurtleKeyboardControl:
    def __init__(self):
        rospy.init_node('keyboard_control', anonymous=True)
        
        # Create publishers for each turtle
        self.vel_pubs = []
        for i in range(1, 9):
            topic_name = f'/turtle{i}/cmd_vel'
            vel_pub = rospy.Publisher(topic_name, Twist, queue_size=10)
            self.vel_pubs.append(vel_pub)
        
        for i in range(17, 20):
            topic_name = f'/turtle{i}/cmd_vel'
            vel_pub = rospy.Publisher(topic_name, Twist, queue_size=10)
            self.vel_pubs.append(vel_pub)
            
        self.speed = 2.0
        self.turn = 2.0

        self.listener = keyboard.Listener(on_press=self.on_press, on_release=self.on_release)

    def on_press(self, key):
        twist = Twist()
        if key == keyboard.Key.up:
            twist.linear.x = self.speed
        elif key == keyboard.Key.down:
            twist.linear.x = -self.speed
        elif key == keyboard.Key.left:
            twist.angular.z = self.turn
        elif key == keyboard.Key.right:
            twist.angular.z = -self.turn
        
        # Publish to all turtles
        for pub in self.vel_pubs:
            pub.publish(twist)

    def on_release(self, key):
        if key == keyboard.Key.esc:
            # Stop listener
            rospy.loginfo("ESC key pressed. Exiting...")
            return False
        
        # Stop all turtles
        twist = Twist()
        for pub in self.vel_pubs:
            pub.publish(twist)

    def start(self):
        self.listener.start()
        rospy.spin()
        self.listener.stop()

if __name__ == '__main__':
    try:
        control = TurtleKeyboardControl()
        control.start()
    except rospy.ROSInterruptException:
        pass

