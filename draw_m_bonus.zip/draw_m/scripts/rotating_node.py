#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist

def rotate_turtles():
    rospy.init_node('rotating_node', anonymous=True)
    rate = rospy.Rate(1)  # Rotate at 1 Hz

    # Create publishers for velocity commands for each turtle
    turtle_vel_pubs = []
    for i in range(1, 20):
        topic_name = '/turtle{}/cmd_vel'.format(i)
        vel_pub = rospy.Publisher(topic_name, Twist, queue_size=10)
        turtle_vel_pubs.append(vel_pub)

    # Create a Twist message for rotation
    twist = Twist()
    twist.angular.z = 1.0  # Rotate counterclockwise

    while not rospy.is_shutdown():
        # Publish the Twist message to rotate each turtle
        for pub in turtle_vel_pubs:
            pub.publish(twist)
        rate.sleep()

if __name__ == '__main__':
    try:
        rotate_turtles()
    except rospy.ROSInterruptException:
        pass

